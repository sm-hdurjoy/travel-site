import React from "react";
import AvatarImage  from "../assets/avatar.jpg";

export const AvatarComponent = () => {
  return (
    <div>
      Avatar
    </div>
  );
};
