import React from "react";
import PageNotFoundImage from "../assets/PageNotFound.jpg";

export const PageNotFound = () => {
  return (
    <div>
      <img src={PageNotFoundImage} alt="" />
    </div>
  );
};
