import React from 'react'

export const Destination = () => {
  return (
    <div>Destination</div>
  )
}
